@extends('outerpage.mainlayoutinnerpage')
@section('css')
<style>
.speaker img{
    
    width:350px;
    height:330px;
}
</style>

@endsection


@section('content')
<main id="main" class="main-page">
<!--==========================
      Speakers Section
    ============================-->
    <section id="speakers" class="wow fadeInUp ">
        <div class="container">

          <div class="section-header">
            <h2>Organizing Committee</h2>
            <p>Organizing Committee</p>
          </div>

          <div class="row">
            <div class="col-lg-4 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Arun.jpg') }}"
                  alt="Speaker 1"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Maj. Gen. Dr. Arun Kumar Neopane (Retd.) </a></h3>
                  <p>Organising Chairperson</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/RamHari.jpg') }}"
                  alt="Speaker 2"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Ram Hari Chapagain</a></h3>
                  <p>Organising Co-Chair</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/prakash.jpg') }}"
                  alt="Speaker 3"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Prakash Joshi</a></h3>
                  <p>Organising Secretary</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          <div class="section-header">
            <!-- <h2>Organizing Sub Committee</h2> -->
            <p>Organizing Sub Committee</p>
          </div>

          <div class="row">
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Keshav.jpg') }}"
                  alt="Speaker 1"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Keshav Prasad Agrawal</a></h3>
                  <p>Finance and Registration</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Deepak.jpg') }}"
                  alt="Speaker 2"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Deepak Rajbhandari</a></h3>
                  <p>Transport and Travel</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/sangitashakya.jpg') }}"
                  alt="Speaker 3"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Sangita Shakya</a></h3>
                  <p>Hospitality and Cultural</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Smriti.jpg') }}"
                  alt="Speaker 4"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Smriti Mathema</a></h3>
                  <p>Scientific</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/SantoshA.jpg') }}"
                  alt="Speaker 5"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Santosh Adhikari</a></h3>
                  <p>IT and Event Management</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Love.jpg') }}"
                  alt="Speaker 6"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Love Kumar Sah</a></h3>
                  <p>Publicity</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Pawana.jpeg') }}"
                  alt="Speaker 6"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Pawana Kayastha</a></h3>
                  <p>Reception</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/SangitaPuree.jpg') }}"
                  alt="Speaker 6"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Sangita Puree Dhungana</a></h3>
                  <p>Memento & Prizes</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 ">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Ramchanda.jpeg') }}"
                  alt="Speaker 6"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Ram Chandra Bastola</a></h3>
                  <p>Trade and Stall</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/Srijana.jpg') }}"
                  alt="Speaker 6"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Srijana Basnet</a></h3>
                  <p>Workshop</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6">
              <div class="speaker">
                <img
                  src="{{ asset('NEPAS_/SantoshP.jpeg') }}"
                  alt="Speaker 6"
                  class="img-fluid"
                />
                <div class="details">
                  <h3><a href="#">Dr. Santosh Pokhrel</a></h3>
                  <p>e-Souvenir</p>
                  <div class="social">
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!--==========================
      Schedule Section
    ============================-->
</main>
@endsection
